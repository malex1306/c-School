﻿namespace Quersumme
{
    class Program
    {
        static void Main()
        {
            try
            {
                {

                    Console.Write("Gib eine Zahl ein: ");
                    int zahl = int.Parse(Console.ReadLine()!);
                    int quersumme = 0;

                    while (zahl > 0)
                    {
                        quersumme += zahl % 10; // zerlegt die zahl
                        zahl /= 10; /*entfernt die letzte Ziffer, indem die Zahl um 
                                     eine Stelle nach rechts verschoben wird.*/
                    }

                    Console.WriteLine("Die Quersumme ist: " + quersumme);

                }


            }

            catch (FormatException)
            {
                Console.WriteLine("Fehler: Bitte geben Sie gültige Zahlen ein.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ein unerwarteter Fehler ist aufgetreten: {ex.Message}");
            }
        }
    }
}

       